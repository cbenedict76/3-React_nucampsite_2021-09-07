import React from "react";

function Home(props) {
  return (
    <div className="container">
      <h4>Home</h4>
    </div>
  );
}

export default Home;